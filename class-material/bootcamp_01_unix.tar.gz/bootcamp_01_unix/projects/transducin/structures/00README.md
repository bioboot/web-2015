## Transducin sequence-structure analysis

Q. Do transducin sequence differences (sequence families) correlate with 
structural differences (conformations)?

## Date Started:
2015-08-22

See: scripts dir for full details 
